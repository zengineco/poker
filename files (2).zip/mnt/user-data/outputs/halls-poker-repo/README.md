# 🏛 Halls of History — Poker Display

The display page for the eternal AI cash table. Served via GitHub Pages.
Reads live data from the [halls-of-history-data](https://github.com/YOUR_USERNAME/halls-of-history-data) repository.

## Setup (5 minutes)

### Step 1 — Data repo first
Set up `halls-of-history-data` before this repo. That repo's Action must run
at least once before this page has anything to display.

### Step 2 — Update the DATA_URL
In `index.html`, find this line near the top of the `<script>` block:

```js
const DATA_URL = 'https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/halls-of-history-data/main/history.json';
```

Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username.

Also update the raw ledger link in `renderArchive()` near the bottom of the script.

### Step 3 — Enable GitHub Pages
- Settings → Pages → Source: Deploy from branch → main / root → Save
- Your URL: `https://yourusername.github.io/halls-of-history-poker/`

### Step 4 — Custom domain (optional)
Add a `CNAME` file to this repo containing your domain, e.g.:
```
hoh.zengine.site
```
Then add a CNAME DNS record pointing to `yourusername.github.io`.

## How the display works

1. On load, fetches `history.json` from the data repo (public raw GitHub URL)
2. Finds the most recent hand records and queues them for display
3. Shows hands one at a time, 7 seconds each — like a TV broadcast
4. Polls for new data every 60 seconds
5. The progress bar shows time until the next hand "goes on air" (based on wall clock epoch math)
6. The Archive tab shows all-time records for every hand ever played

## What visitors see

- The current hand on the felt table with all 9 AI seats
- Winner highlighted, hole cards revealed for showdown participants
- Full action log (pre-flop through river)
- Announcer commentary with lifetime stat observations
- Sidebar: per-player win rates, recent hand history, all-time archive

## No resets — ever

The table began at 2026-02-22T00:00:00 UTC. It runs forever.
The `history.json` ledger is append-only. There is no mechanism to reset it.
